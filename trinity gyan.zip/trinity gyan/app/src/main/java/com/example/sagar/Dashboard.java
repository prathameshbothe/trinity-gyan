package com.example.sagar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Dashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView idphoto = (ImageView) findViewById(R.id.idphoto);

        idphoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ilog;
                ilog = new Intent(Dashboard.this,Support.class);
                startActivity(ilog);
            }
        });

        ImageView idquiz = (ImageView) findViewById(R.id.idquiz);

        idquiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ilog;
                ilog = new Intent(Dashboard.this,Quiz_subject.class);

                startActivity(ilog);
            }
        });


        ImageView idres = (ImageView) findViewById(R.id.resultshow);

        idres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ires ;
                ires= new Intent(Dashboard.this,Result_page.class);
                startActivity(ires);
            }
        });

        ImageView idpyq = (ImageView) findViewById(R.id.idpyq);

        idpyq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ipyq ;
                ipyq= new Intent(Dashboard.this,Pdf_button.class);
                startActivity(ipyq);
            }
        });

        ImageView idsyllabus = (ImageView) findViewById(R.id.idsyllabus);

        idsyllabus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent islb ;
                islb= new Intent(Dashboard.this,Pdf_syllabus.class);
                startActivity(islb);
            }
        });

        ImageView iddeveloper = (ImageView) findViewById(R.id.iddev);

        iddeveloper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent idev ;
                idev= new Intent(Dashboard.this,Developer_bg.class);
                startActivity(idev);
            }
        });


    }
}