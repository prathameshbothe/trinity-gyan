package com.example.sagar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.sagar.R;
import com.github.barteksc.pdfviewer.PDFView;


public class Pdf_button extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pdf_button);

        PDFView pdfView = findViewById(R.id.pdf_view);

        pdfView.fromAsset("first_sem.pdf").load();
    }
}