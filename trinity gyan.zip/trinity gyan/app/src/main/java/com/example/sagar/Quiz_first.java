package com.example.sagar;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Quiz_first extends AppCompatActivity implements View.OnClickListener {

    TextView totalQuestionsTextView ;
    TextView questionTextView  ;
    Button ansa , ansb , ansc , ansd ;

    Button submitbtn ;

    int score = 0 ;

    int totalQuestion = QuestionsAnswer.question.length;

    int currentQuestionIndex = 0 ;

    String selectedAnswer = "" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quiz_first);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        totalQuestionsTextView= findViewById(R.id.total_question);
        questionTextView = findViewById(R.id.question);
        ansa = findViewById(R.id.ans_a);
        ansb = findViewById(R.id.ans_b);
        ansc = findViewById(R.id.ans_c);

        ansd = findViewById(R.id.ans_d);

        submitbtn = findViewById(R.id.submitbtn);

        ansa.setOnClickListener(this);
        ansb.setOnClickListener(this);
        ansc.setOnClickListener(this);
        ansd.setOnClickListener(this);

        submitbtn.setOnClickListener(this);

        totalQuestionsTextView.setText("total question"+totalQuestion);

        loadNewQuestion();


    }

    @Override
    public void onClick(View v) {


        ansa.setBackgroundColor(Color.WHITE);
        ansb.setBackgroundColor(Color.WHITE);
        ansc.setBackgroundColor(Color.WHITE);
        ansd.setBackgroundColor(Color.WHITE);


        Button clickedButton = (Button) v ;
        if(clickedButton.getId()==R.id.submitbtn)
        {

            if(selectedAnswer.equals(QuestionsAnswer.CorrectAnswer[currentQuestionIndex]))
            {
                score++;
            }
            currentQuestionIndex++;
            loadNewQuestion();

        }else
        {
            // choices button clicked
            selectedAnswer = clickedButton.getText().toString();
            clickedButton.setBackgroundColor(Color.MAGENTA);
        }


    }

    void  loadNewQuestion()
    {

        if(currentQuestionIndex == totalQuestion)
        {
            finishQuiz();
            return ;
        }

        questionTextView.setText(QuestionsAnswer.question[currentQuestionIndex]);
        ansa.setText(QuestionsAnswer.choices[currentQuestionIndex][0]);
        ansb.setText(QuestionsAnswer.choices[currentQuestionIndex][1]);
        ansc.setText(QuestionsAnswer.choices[currentQuestionIndex][2]);
        ansd.setText(QuestionsAnswer.choices[currentQuestionIndex][3]);
    }

    void finishQuiz()
    {
        String passStatus = "";
        if(score>totalQuestion*0.60)
        {
            passStatus = "PASSED";
        }else
        {
            passStatus = "FAILED";
        }
        new AlertDialog.Builder(this)
                .setTitle(passStatus)
                .setMessage(" Your Score is : "+score+" out of"+totalQuestion)
                .setPositiveButton("Restart",((dialogInterface, i) -> restartQuiz()))
                .setCancelable(false)
                .show();
    }

    void restartQuiz()
    {
        score = 0 ;
        currentQuestionIndex = 0 ;
        loadNewQuestion();
    }
}