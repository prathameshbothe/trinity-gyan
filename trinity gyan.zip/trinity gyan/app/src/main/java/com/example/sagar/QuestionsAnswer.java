package com.example.sagar;

public class QuestionsAnswer {

    public static String question[]={
            "1) Which of the following is not an operating system?",
            "2) When was the first operating system developed?",
            "3) What else is a command interpreter called?",
            "4) What is the mean of the Booting in the operating system?",
             "5) Which of the following is the extension of Notepad?",
              "6) Banker's algorithm is used?",
            "7) Which is the Linux operating system? ",
            "8) If the page size increases, the internal fragmentation is also? ",
            "9) Which of the following is a single-user operating system? ",
            "10) The size of virtual memory is based on which of the following? "
    };

    public static String choices[][]= {

            {"a. windows ", "b. Linux", "c. Oracle", "d. Dos"},
            {"a. 1950", "b. 1955 ", "c. 1948", "d. 1942"},
            {"a. prompt", "b. kernel", "c. shell", "d. command"},
            {"a. Restarting computer","b. Install the program","c. to scan","d. to turn of"},
            {"a .txt","b .xls","c .ppt ","d .bmp"},
            {"a. To prevent deadlock","b. To deadlock recovery","c. To solve the deadlock","d. None of these"},
            {"a. Private operating system","b. Windows operating system", "c. Open-source operating system","d. None of these"},
            {"a. Decreases","b. Increases","c. Remains constant","d. None of these"},
            {"a. Windows","b. MAC","c. Ms-Dos","d. None of these"},
            {"a. CPU","b. RAM","c. Address bus","d. Data bus"}

    };

    public static String CorrectAnswer[]={

            "c. Oracle","a. 1950","c. shell","a. Restarting computer","a .txt","a. To prevent deadlock","c. Open-source operating system","b. Increases",
            "c. Ms-Dos","c. Address bus"
    };
}
